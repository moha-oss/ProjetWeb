-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 29 mars 2023 à 02:36
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestion_emploi_du_temps`
--

-- --------------------------------------------------------

--
-- Structure de la table `aderme`
--

CREATE TABLE `aderme` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `adigmp`
--

CREATE TABLE `adigmp` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `adiifa`
--

CREATE TABLE `adiifa` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `adiigc`
--

CREATE TABLE `adiigc` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `adiiris`
--

CREATE TABLE `adiiris` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `adiirsi`
--

CREATE TABLE `adiirsi` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `adiisa`
--

CREATE TABLE `adiisa` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `altbicg`
--

CREATE TABLE `altbicg` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `altmaip`
--

CREATE TABLE `altmaip` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `altmipc`
--

CREATE TABLE `altmipc` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `amtbiov`
--

CREATE TABLE `amtbiov` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `amtexvg`
--

CREATE TABLE `amtexvg` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `amtgeaa`
--

CREATE TABLE `amtgeaa` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `amtgeel`
--

CREATE TABLE `amtgeel` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `amtmaav`
--

CREATE TABLE `amtmaav` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `amtmcsm`
--

CREATE TABLE `amtmcsm` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `amtmdim`
--

CREATE TABLE `amtmdim` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `amtmiai`
--

CREATE TABLE `amtmiai` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `amtmmea`
--

CREATE TABLE `amtmmea` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `amtpsnb`
--

CREATE TABLE `amtpsnb` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `amtrdps`
--

CREATE TABLE `amtrdps` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `amtsdad`
--

CREATE TABLE `amtsdad` (
  `id` int(11) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `prof` varchar(255) NOT NULL,
  `duree` varchar(255) NOT NULL,
  `jour` varchar(255) NOT NULL,
  `sale` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `respo`
--

CREATE TABLE `respo` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `aderme`
--
ALTER TABLE `aderme`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `adigmp`
--
ALTER TABLE `adigmp`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `adiifa`
--
ALTER TABLE `adiifa`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `adiigc`
--
ALTER TABLE `adiigc`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `adiiris`
--
ALTER TABLE `adiiris`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `adiirsi`
--
ALTER TABLE `adiirsi`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `adiisa`
--
ALTER TABLE `adiisa`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `altbicg`
--
ALTER TABLE `altbicg`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `altmaip`
--
ALTER TABLE `altmaip`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `altmipc`
--
ALTER TABLE `altmipc`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `amtbiov`
--
ALTER TABLE `amtbiov`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `amtexvg`
--
ALTER TABLE `amtexvg`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `amtgeaa`
--
ALTER TABLE `amtgeaa`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `amtgeel`
--
ALTER TABLE `amtgeel`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `amtmaav`
--
ALTER TABLE `amtmaav`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `amtmcsm`
--
ALTER TABLE `amtmcsm`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `amtmdim`
--
ALTER TABLE `amtmdim`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `amtmiai`
--
ALTER TABLE `amtmiai`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `amtmmea`
--
ALTER TABLE `amtmmea`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `amtpsnb`
--
ALTER TABLE `amtpsnb`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `amtrdps`
--
ALTER TABLE `amtrdps`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `amtsdad`
--
ALTER TABLE `amtsdad`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `aderme`
--
ALTER TABLE `aderme`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `adigmp`
--
ALTER TABLE `adigmp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `adiifa`
--
ALTER TABLE `adiifa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `adiigc`
--
ALTER TABLE `adiigc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `adiiris`
--
ALTER TABLE `adiiris`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `adiirsi`
--
ALTER TABLE `adiirsi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `adiisa`
--
ALTER TABLE `adiisa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `altbicg`
--
ALTER TABLE `altbicg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `altmaip`
--
ALTER TABLE `altmaip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `altmipc`
--
ALTER TABLE `altmipc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `amtbiov`
--
ALTER TABLE `amtbiov`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `amtexvg`
--
ALTER TABLE `amtexvg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `amtgeaa`
--
ALTER TABLE `amtgeaa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `amtgeel`
--
ALTER TABLE `amtgeel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `amtmaav`
--
ALTER TABLE `amtmaav`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `amtmcsm`
--
ALTER TABLE `amtmcsm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `amtmdim`
--
ALTER TABLE `amtmdim`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `amtmiai`
--
ALTER TABLE `amtmiai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `amtmmea`
--
ALTER TABLE `amtmmea`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `amtpsnb`
--
ALTER TABLE `amtpsnb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `amtrdps`
--
ALTER TABLE `amtrdps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `amtsdad`
--
ALTER TABLE `amtsdad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
