<?php
    if(isset($_POST["valider"])){
        require 'connect.php';
        $filiere = $_POST['filiere'];
        $matr = $_POST['matr'];
        $prof = $_POST['prof'];
        $duree = $_POST['duree'];
        $jour = $_POST['jour'];
        $sale = $_POST['sale'];

        $sql="SELECT * FROM $filiere";
        $res = $pdo->query($sql);
        $data = $res->fetchAll();
        
        $chec = false;
        foreach($data as $d){
            if($duree == $d['duree'] && $jour == $d['jour']){
                $req = "UPDATE $filiere SET 
                    `filiere`='$filiere',`matiere`='$matr',`prof`='$prof',`sale`='$sale' WHERE `duree` = '$duree' and `jour` = '$jour'";
                $pdo->exec($req);
                $chec = true;
                header('location: ../ajouterseanceform.php');

                exit();
            }
        }
        
        if($chec == false){
            $req2 = "INSERT INTO $filiere (`filiere`, `matiere`, `prof`, `duree`, `jour`, `sale`)
                VALUES ('$filiere','$matr','$prof','$duree','$jour','$sale')";
            $pdo->exec($req2);
            $chec = true;
            header('location: ../ajouterseanceform.php');
            
            exit();
        }
    
    }
?>