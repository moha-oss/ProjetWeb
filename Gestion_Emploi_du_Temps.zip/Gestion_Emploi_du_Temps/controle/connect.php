<?php
    try{
        $pdo = new PDO("mysql:host=localhost;dbname=gestion_emploi_du_temps","root","");

    }catch(PDOExeption $e){
        die("ERROR:peut pas connecter". $e->getMessage());
    }
?>