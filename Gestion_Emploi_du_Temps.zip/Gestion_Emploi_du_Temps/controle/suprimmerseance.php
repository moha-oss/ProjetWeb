<?php

    if(isset($_POST['valider'])){
        require 'connect.php';

        $filiere = $_POST['filiere'];
        $duree = $_POST['duree'];
        $jour = $_POST['jour'];

        if(!empty($filiere) || !empty($duree) || !empty($jour)){
            $sql="DELETE FROM $filiere WHERE duree = '$duree' and jour = '$jour'";
            $pdo->exec($sql);
            header('location: ../suprimmerseanceform.php');
            echo 'supression avec success';
            exit();
        }else{
            header('location: ../suprimmerseanceform.php');
            echo 'Veuillez remplir tous les champs';
            exit();
        }
    }
?>