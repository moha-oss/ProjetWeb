<?php

    $intitule = array('ALTBICG'=>'Licence Sc. & Techn Biologie Chimie Géologie',
    'ALTMIPC'=>'Licence Sc. & Tech Math Informatique Physique -Chimie',
    'ALTMAIP'=>'Licence Sc. & Tech Math App. Informatique - Physique',
    'AMTMAAV'=>'MASTER Matériaux Avancés',
    'AMTSDAD'=>'Sciences des données et aide à la décision	',
    'AMTEXVG'=>'Master Exploration et Valorisation des Géoressources',
    'AMTMCSM'=>"AMASTER Mod. Calcul Scient. pr l'Ingénierie Mathématique",
    'AMTGEEL'=>'Master Genie Elecrique	',
    'AMTBIOV'=>"Biotechnologie Végétale pour l'amélioration des plantes",
    'AMTMIAI'=>'AMTMIAI',
    'AMTGEAA'=>'Geometrie Analyse Et Application',
    'AMTRDPS'=>'Master RECHERCHE ET DEVELOPPEMENT EN PHYSICO-CHIM',
    'AMTMDIM'=>'AMTMDIM',
    'AMTMMEA'=>'AMTMMEA',
    'AMTPSNB'=>'AMTPSNB',
    'ADIISA'=>"Ingénieur d'Etat - Industrie et Sécurité des Aliments",
    'ADIIFA'=>'Ingénerie en Finance et Actuariat',
    'ADIIRSI'=>"Ingénierie en Réseaux informatique et Systèmes d'Information",
    'ADERME'=>'ENERGIES RENOUVELABLES et MOBILITE ELECTRIQUE',
    'ADIGMP'=>'Génie des Matériaux et Procédés',
    'ADIIGC'=>'Génie Civil',
    'ADIIRIS'=>'ADIIRIS');
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            text-align: center;
            font-family: arial, sans-serif;
        }
        table {
            border-collapse: collapse;
            width:100%;
        }
        hr{
            color: #4f6aff;
            width: 80%;
        }
        td, th {
            width: 10%;
            font-size: 15px;
            border: 1px solid #000000;
            text-align: center;
            padding: 5px;
        }
        th{
            height: 40px;
        }
        td{
            height: 60px;
        }
        .jour{
            background-color: #7573fc;
        }
        .vide{
            border: none;
        }
        header img{
            width: 250px;
            height: 100px;
        }
    </style>
</head>
<body>
    <header>
        <img src="src/logo.jpg" alt="Logo FST">
        <hr>
        <h4>Emploi du temps: <?php echo $filiere ."<br>".$intitule[$filiere]?></h4>

    </header>
    <table>
        <tr>
            <th class="vide"></th>
            <th class="jour">8:30 - 10:30</th>
            <th class="jour">10:30 - 12:30</th>
            <th class="jour">14:30 - 16:30</th>
            <th class="jour">16:30 - 18:30</th>
        </tr>
        <tr>
            <td class="jour">Lundi</td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "8:30 - 10:30" && $data[$i]['jour'] == "lundi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
                
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "10:30 - 12:30" && $data[$i]['jour'] == "lundi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "14:30 - 16:30" && $data[$i]['jour'] == "lundi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "16:30 - 18:30" && $data[$i]['jour'] == "lundi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
        </tr>
        <tr>
            <td class="jour">Mardi</td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "8:30 - 10:30" && $data[$i]['jour'] == "mardi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
                
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "10:30 - 12:30" && $data[$i]['jour'] == "mardi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "14:30 - 16:30" && $data[$i]['jour'] == "mardi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "16:30 - 18:30" && $data[$i]['jour'] == "mardi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
        </tr>
        <tr>
            <td class="jour">Mercredi</td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "8:30 - 10:30" && $data[$i]['jour'] == "mercredi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
                
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "10:30 - 12:30" && $data[$i]['jour'] == "mercredi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "14:30 - 16:30" && $data[$i]['jour'] == "mercredi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "16:30 - 18:30" && $data[$i]['jour'] == "mercredi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
        </tr>
        <tr>
            <td class="jour">Jeudi</td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "8:30 - 10:30" && $data[$i]['jour'] == "jeudi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
                
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "10:30 - 12:30" && $data[$i]['jour'] == "jeudi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "14:30 - 16:30" && $data[$i]['jour'] == "jeudi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "16:30 - 18:30" && $data[$i]['jour'] == "jeudi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
        </tr>
        <tr>
            <td class="jour">Vendredi</td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "8:30 - 10:30" && $data[$i]['jour'] == "vendredi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
                
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "10:30 - 12:30" && $data[$i]['jour'] == "vendredi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "14:30 - 16:30" && $data[$i]['jour'] == "vendredi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "16:30 - 18:30" && $data[$i]['jour'] == "vendredi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
        </tr>
        <tr>
            <td class="jour">Samedi</td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "8:30 - 10:30" && $data[$i]['jour'] == "samedi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "10:30 - 12:30" && $data[$i]['jour'] == "samedi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "14:30 - 16:30" && $data[$i]['jour'] == "samedi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
            <td><?php
                for($i = 0; $i < count($data); $i++){
                    if($data[$i]['duree']== "16:30 - 18:30" && $data[$i]['jour'] == "samedi"){
                        echo $data[$i]['matiere']."<br>".$data[$i]['prof']."<br>".$data[$i]['sale'];
                    }
                }
            ?></td>
        </tr>
    </table><br>
    <hr>
</body>
</html>