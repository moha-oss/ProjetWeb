<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style/stylehomeemploi.css">
</head>
<body id="body">
    <br><br>
    <div class="con">   
        <label for="trouve">Cherche Filière:</label>
        <input type="text" name="trouve" placeholder="filière" id="input">
        <button type="submit" onclick="cherche();">Cherche</button>
    </div>
    
    <div>
        <h2>Emploi du temps: Diplôme Licence</h2>
        <table id="tab1">
            <tr>
                <th class="filiere">Intitulé de la filière</th>
                <th>Emploi du temps</th>
            </tr>
            <tr>
                <td class="filiere">Licence Sc. & Techn Biologie Chimie Géologie</td>
                <td><?php
                    $f='ALTBICG';
                    echo'<a href="emploifini.php?filiere='.$f.'">BICG</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">Licence Sc. & Tech Math Informatique Physique -Chimie</td>
                <td><?php
                    $f='ALTMIPC';
                    echo'<a href="emploifini.php?filiere='.$f.'">MIPC</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">Licence Sc. & Tech Math App. Informatique - Physique</td>
                <td><?php
                    $f='ALTMAIP';
                    echo'<a href="emploifini.php?filiere='.$f.'">MAIP</a>';
                ?></td>
            </tr>
        </table>
    </div><br>

    <div>
        <h2>Emploi du temps: Diplôme Mater</h2>
        <table id="tab2">
            <tr>
                <th class="filiere">Intitulé de la filière</th>
                <th>Emploi du temps</th>
            </tr>
            <tr>
                <td class="filiere">MASTER Matériaux Avancés</td>
                <td><?php
                    $f='AMTMAAV';
                    echo'<a href="emploifini.php?filiere='.$f.'">MAAV</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">Sciences des données et aide à la décision</td>
                <td><?php
                    $f='AMTSDAD';
                    echo'<a href="emploifini.php?filiere='.$f.'">SDAD</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">Master Exploration et Valorisation des Géoressources</td>
                <td><?php
                    $f='AMTEXVG';
                    echo'<a href="emploifini.php?filiere='.$f.'">EXVG</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">AMASTER Mod. Calcul Scient. pr l'Ingénierie Mathématique</td>
                <td><?php
                    $f='AMTMCSM';
                    echo'<a href="emploifini.php?filiere='.$f.'">MCSM</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">Master Genie Elecrique</td>
                <td><?php
                    $f='AMTGEEL';
                    echo'<a href="emploifini.php?filiere='.$f.'">GEEL</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">Biotechnologie Végétale pour l'amélioration des plantes</td>
                <td><?php
                    $f='AMTBIOV';
                    echo'<a href="emploifini.php?filiere='.$f.'">BIOV</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">AMTMIAI</td>
                <td><?php
                    $f='AMTMIAI';
                    echo'<a href="emploifini.php?filiere='.$f.'">MIAI</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">Geometrie Analyse Et Application</td>
                <td><?php
                    $f='AMTGEAA';
                    echo'<a href="emploifini.php?filiere='.$f.'">GEAA</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">Master RECHERCHE ET DEVELOPPEMENT EN PHYSICO-CHIM</td>
                <td><?php
                    $f='AMTRDPS';
                    echo'<a href="emploifini.php?filiere='.$f.'">RDPS</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">AMTMDIM</td>
                <td><?php
                    $f='AMTMDIM';
                    echo'<a href="emploifini.php?filiere='.$f.'">MDIM</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">AMTMMEA</td>
                <td><?php
                    $f='AMTMMEA';
                    echo'<a href="emploifini.php?filiere='.$f.'">MMEA</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">AMTPSNB</td>
                <td><?php
                    $f='AMTPSNB';
                    echo'<a href="emploifini.php?filiere='.$f.'">PSNB</a>';
                ?></td>
            </tr>
        </table>
    </div><br>

    <div>
        <h2>Emploi du temps: Diplôme Ingenieur</h2>
        <table id="tab3">
            <tr>
                <th class="filiere">Intitulé de la filière</th>
                <th>Emploi du temps</th>
            </tr>
            <tr>
                <td class="filiere">Ingénieur d'Etat - Industrie et Sécurité des Aliments</td>
                <td><?php
                    $f='ADIISA';
                    echo'<a href="emploifini.php?filiere='.$f.'">ADIISA</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">Ingénerie en Finance et Actuariat</td>
                <td><?php
                    $f='ADIIFA';
                    echo'<a href="emploifini.php?filiere='.$f.'">ADIIFA</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">Ingénierie en Réseaux informatique et Systèmes d'Information</td>
                <td><?php
                    $f='ADIIRSI';
                    echo'<a href="emploifini.php?filiere='.$f.'">ADIIRSI</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">ENERGIES RENOUVELABLES et MOBILITE ELECTRIQUE</td>
                <td><?php
                    $f='ADERME';
                    echo'<a href="emploifini.php?filiere='.$f.'">ADERME</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">Génie des Matériaux et Procédés</td>
                <td><?php
                    $f='ADIGMP';
                    echo'<a href="emploifini.php?filiere='.$f.'">ADIGMP</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">Génie Civil</td>
                <td><?php
                    $f='ADIIGC';
                    echo'<a href="emploifini.php?filiere='.$f.'">ADIIGC</a>';
                ?></td>
            </tr>
            <tr>
                <td class="filiere">ADIIRIS</td>
                <td><?php
                    $f='ADIIRIS';
                    echo'<a href="emploifini.php?filiere='.$f.'">ADIIRIS</a>';
                ?></td>
            </tr>
        </table>
    </div><br>

    <script>
        function cherche() {
        // Declare variables
            var input, filter, table1, tr, td, i, txtValue;
            var table2;
            var table3;
            input = document.getElementById("input");
            filter = input.value.toUpperCase();

            table1 = document.getElementById("tab1");
            tr = table1.getElementsByTagName("tr");

            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[1];
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                        tr[i].style.color = "red";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }

            table2 = document.getElementById("tab2");
            tr = table2.getElementsByTagName("tr");
            for (i = 0; i < tr.length; i++) {
                td1 = tr[i].getElementsByTagName("td")[1];
                if (td1) {
                    txtValue = td1.textContent || td1.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                        tr[i].style.color = "red";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }

            table3 = document.getElementById("tab3");
            tr = table3.getElementsByTagName("tr");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[1];
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                        tr[i].style.color = "red";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>
</body>
</html>