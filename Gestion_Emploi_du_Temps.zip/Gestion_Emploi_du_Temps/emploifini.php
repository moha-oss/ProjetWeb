<?php
    use Dompdf\Dompdf;
    use Dompdf\Options;
    
    require 'controle/connect.php';
    
    $filiere=$_GET['filiere'];
    $sql="SELECT * FROM $filiere";
    $res = $pdo->query($sql);
    $data = $res->fetchAll();

    require_once 'dompdf/autoload.inc.php';

    ob_start();
    require_once 'emploidocument.php';
    $pdf=ob_get_contents();
    ob_end_clean();

    $options = new Options();
    $options->set('chroot',realpath(''));

    $dompdf = new Dompdf($options);
    $dompdf->loadHtml($pdf);
    $dompdf->render();
    $dompdf->stream("Emploi du temps $filiere", array("Attachment" => false));

?>