<?php
session_start();

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style/stylehomeemploi.css?v=<?php echo time();?>">
</head>
<body>
    <header>
        <img src="src/logo.jpg" alt="logo FST">
        <h4>Bonjour <?php echo $_SESSION['admin'] ?> </h4>
        <ul>
            <li><a href="ajouterseanceform.php">Ajouter une séance</a></li>
            <li><a href="suprimmerseanceform.php">Liberer une période</a></li>
            <li><a href="emploiadmin.php">Emploi du temps</a></li>
            <li><a href="controle/deconnecter.php">Deconnecter</a></li>
        </ul>
    </header>
    <main>

    </main>
    <footer class="home">
        <h3>Copiright FSTG</h3>
    </footer>
</body>
</html>