<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style/style.css?v=<?php echo time(); ?>">
</head>
<body>
    <header>
        <img src="src/logo.jpg" alt="logo FST">
        <h1>Gestion d'emploi du temps</h1>
    </header><br>
    <p id="def" >Cette aplication vous permet la gestion d'emploi du temps, Vous êtes Admin connecter vous:</p>
    <form class="login" method="POST" action="login.php">
        <h2>Se Connecter</h2>

        <?php
            if(isset($email_erreur)){
                echo "<p>".$email_erreur."</p>";
            }
        ?>
        <input type="email" name="email" placeholder="Email">

        <?php
            if(isset($pass_erreur)){
                echo "<p>".$pass_erreur."</p>";
            }
        ?>
        <input type="password" name="password" placeholder="Mot de pass">
        <br>
        
        <button type="submit" name="submit">Connecter</button><br>
        <a href="inscrireform.php">pas de compte: Inscrire</a><br><br>
    </form><br><br>
    <footer id="footerlogin">
        <h3>Copiright FSTG</h3>
    </footer>
</body>
</html>