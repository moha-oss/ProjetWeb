<?php
    
    if(isset($_POST['submit'])){
        require('controle/connect.php');
        session_start();
        $email = stripcslashes($_POST['email']);
        $pass = md5(stripcslashes($_POST['password']));

        $sql="SELECT * FROM respo";
        $res = $pdo->query($sql);
        $data = $res->fetch();

        $erreur=0;
        $prenom = $data['prenom'];
        $_SESSION['admin']=$prenom;


        if(empty($email)){
            $email_erreur="Vous devez entrer l'email";
            $erreur=1;
        }elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $email_erreur="Vous devez entrer un email correct";
            $erreur=1;
        }elseif(
            $data['email'] != $email){
            $email_erreur="l'email incorrect";
            $erreur=1;
        }
        if(empty($pass)){
            $pass_erreur="Vous devez entrer le mot de passe";
            $erreur=1;
            include 'index.php';
        }elseif(md5($data['pass']) != $pass){
            $pass_erreur="le mot de passe incorrect";
            $erreur=1;
            include_once 'index.php';
        }else{
            include 'index.php';
        }
        if ($erreur == 0){
            header('location: home.php');
            exit();
        }
    
    }

?>
