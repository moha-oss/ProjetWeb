

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style/styleajoutsupp.css?v=<?php echo time(); ?>">
</head>
<body>
    <header>
        <img src="src/logo.jpg" alt="logo FST">
        <h4>Bonjour <?php 
            session_start();
            echo $_SESSION['admin'];
        ?> </h4>
        <ul>
            <li><a href="ajouterseanceform.php">Ajouter une séance</a></li>
            <li><a href="suprimmerseanceform.php">Liberer une période</a></li>
            <li><a href="emploiadmin.php">Emploi du temps</a></li>
            <li><a href="controle/deconnecter.php">Deconnecter</a></li>
        </ul>
    </header>
    <form method="POST" action="controle/suprimmerseance.php">
        <h2>Liberer une période</h2>
        <select name="filiere" id="filiere">
            <option value="" selected hidden>Filière</option>
            <optgroup label="Diplome-licence">
                <option value="ALTBICG">ALTBICG</option>
                <option value="ALTMIPC">ALTMIPC</option>
                <option value="ALTMAIP">ALTMAIP</option>
            </optgroup>
            <optgroup label="Diplome-master">
                <option value="AMTMAAV">AMTMAAV</option>
                <option value="AMTSDAD">AMTSDAD</option>
                <option value="AMTEXVG">AMTEXVG</option>
                <option value="AMTMCSM">AMTMCSM</option>
                <option value="AMTGEEL">AMTGEEL</option>
                <option value="AMTBIOV">AMTBIOV</option>
                <option value="AMTMIAI">AMTMIAI</option>
                <option value="AMTGEAA">AMTGEAA</option>
                <option value="AMTRDPS">AMTRDPS</option>
                <option value="AMTMDIM">AMTMDIM</option>
                <option value="AMTMMEA">AMTMMEA</option>
                <option value="AMTPSNB">AMTPSNB</option>
            </optgroup>
            <optgroup label="Diplome-ingenieur">
                <option value="ADIISA">ADIISA</option>
                <option value="ADIIFA">ADIIFA</option>
                <option value="ADIIRSI">ADIIRSI</option>
                <option value="ADERME">ADERME</option>
                <option value="ADIGMP">ADIGMP</option>
                <option value="ADIIG">ADIIG</option>
                <option value="ADIIRIS">ADIIRIS</option>

            </optgroup>
        </select>
        <select name="duree">
                <option value="" selected hidden>Période</option>
                <optgroup label="Matin">
                    <option value="8:30 - 10:30">8:30 - 10:30</option>
                    <option value="10:30 - 12:30">10:30 - 12:30</option>
                </optgroup>
                <optgroup label="Aprés midi">
                    <option value="14:30 - 16:30">14:30 - 16:30</option>
                    <option value="16:30 - 18:30">16:30 - 18:30</option>
                </optgroup>
            </select>
        <select name="jour">
            <option value="" selected hidden>Le jour</option>
                <option value="lundi">Lundi</option>
                <option value="mardi">Mardi</option>
                <option value="mercredi">Mercredi</option>
                <option value="jeudi">Jeudi</option>
                <option value="vendredi">Vendredi</option>
                <option value="samedi">Samedi</option>
        </select><br><br>
        
        <button type="submit" name="valider" id="valider">Valider</button>
        <p><a href="home.php">Page d'accueille</a></p>

    </form>
    <footer>
        <h3>Copiright FSTG</h3>
    </footer>
</body>
</html>